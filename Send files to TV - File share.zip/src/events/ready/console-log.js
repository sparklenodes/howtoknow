module.exports = (client) => {
  console.log(`${client.user.tag} is online and ready to be used!`);
};
